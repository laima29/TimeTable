package com.example.owner.timetableapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ViewActivit extends AppCompatActivity{

    SQLiteDatabase db;



    TextView monday9;
    TextView monday10;
    TextView monday11;
    TextView monday12;
    TextView monday13;
    TextView monday14;
    TextView monday15;
    TextView monday16;
    TextView monday17;

    TextView tuesday9;
    TextView tuesday10;
    TextView tuesday11;
    TextView tuesday12;
    TextView tuesday13;
    TextView tuesday14;
    TextView tuesday15;
    TextView tuesday16;
    TextView tuesday17;

    TextView wednesday9;
    TextView wednesday10;
    TextView wednesday11;
    TextView wednesday12;
    TextView wednesday13;
    TextView wednesday14;
    TextView wednesday15;
    TextView wednesday16;
    TextView wednesday17;

    TextView thursday9;
    TextView thursday10;
    TextView thursday11;
    TextView thursday12;
    TextView thursday13;
    TextView thursday14;
    TextView thursday15;
    TextView thursday16;
    TextView thursday17;

    TextView friday9;
    TextView friday10;
    TextView friday11;
    TextView friday12;
    TextView friday13;
    TextView friday14;
    TextView friday15;
    TextView friday16;
    TextView friday17;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        monday9 = (TextView) findViewById(R.id.mon9);
        monday10 = (TextView) findViewById(R.id.mon10);
        monday11 = (TextView) findViewById(R.id.mon11);
        monday12 = (TextView) findViewById(R.id.mon12);
        monday13 = (TextView) findViewById(R.id.mon13);
        monday14 = (TextView) findViewById(R.id.mon14);
        monday15 = (TextView) findViewById(R.id.mon15);
        monday16 = (TextView) findViewById(R.id.mon16);
        monday17 = (TextView) findViewById(R.id.mon17);

        tuesday9 = (TextView) findViewById(R.id.tue9);
        tuesday10 = (TextView) findViewById(R.id.tue10);
        tuesday11 = (TextView) findViewById(R.id.tue11);
        tuesday12 = (TextView) findViewById(R.id.tue12);
        tuesday13 = (TextView) findViewById(R.id.tue13);
        tuesday14 = (TextView) findViewById(R.id.tue14);
        tuesday15 = (TextView) findViewById(R.id.tue15);
        tuesday16 = (TextView) findViewById(R.id.tue16);
        tuesday17 = (TextView) findViewById(R.id.tue17);

        wednesday9 = (TextView) findViewById(R.id.wed9);
        wednesday10 = (TextView) findViewById(R.id.wed10);
        wednesday11 = (TextView) findViewById(R.id.wed11);
        wednesday12 = (TextView) findViewById(R.id.wed12);
        wednesday13 = (TextView) findViewById(R.id.wed13);
        wednesday14 = (TextView) findViewById(R.id.wed14);
        wednesday15 = (TextView) findViewById(R.id.wed15);
        wednesday16 = (TextView) findViewById(R.id.wed16);
        wednesday17 = (TextView) findViewById(R.id.wed17);

        thursday9 = (TextView) findViewById(R.id.thur9);
        thursday10 = (TextView) findViewById(R.id.thur10);
        thursday11 = (TextView) findViewById(R.id.thur11);
        thursday12 = (TextView) findViewById(R.id.thur12);
        thursday13 = (TextView) findViewById(R.id.thur13);
        thursday14 = (TextView) findViewById(R.id.thur14);
        thursday15 = (TextView) findViewById(R.id.thur15);
        thursday16 = (TextView) findViewById(R.id.thur16);
        thursday17 = (TextView) findViewById(R.id.thur17);

        friday9 = (TextView) findViewById(R.id.fri9);
        friday10 = (TextView) findViewById(R.id.fri10);
        friday11 = (TextView) findViewById(R.id.fri11);
        friday12 = (TextView) findViewById(R.id.fri12);
        friday13 = (TextView) findViewById(R.id.fri13);
        friday14 = (TextView) findViewById(R.id.fri14);
        friday15 = (TextView) findViewById(R.id.fri15);
        friday16 = (TextView) findViewById(R.id.fri16);
        friday17 = (TextView) findViewById(R.id.fri17);
        



    }
}
