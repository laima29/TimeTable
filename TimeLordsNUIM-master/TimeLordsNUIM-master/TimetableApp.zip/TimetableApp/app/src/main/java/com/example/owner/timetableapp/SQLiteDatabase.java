package com.example.owner.timetableapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Owner on 18/01/2018.
 */

public class SQLiteDatabase extends SQLiteOpenHelper{

    //Logcat tag
    private static final String LOG = "SQLiteDatabase";

    //Defining database version
    private static final int DATABASE_VERSION = 1;

    //Defining name of the database
    private static final String DATABASE_NAME = "Timetable";

    //Name of the first table, and its columns, and data types
    private static final String TABLE_NAME1 = "Courses";
    private static final String colc_1 = "course_id";
    private static final String colc_2 = "course_name";

    //As before, for the second table, including time values
    private static final String TABLE_NAME2 = "Modules";
    private static final String colm_1 = "module_id";
    private static final String colm_2 = "module_name";
    private static final String colm_3 = "module_venue";
    private static final String colm_4 = "module_time";
    private static final String colm_5 = "module_semester";
    private static final String colm_6 = "module_course";
    private static final String colm_7 = "module_day";
    private static final String colm_8 = "module_year";

    //As before, for the relational table
    private static final String TABLE_NAME3 = "is_in";
    private static final String coli_1 = "c_id";
    private static final String coli_2 = "m_id";

    public SQLiteDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(android.database.sqlite.SQLiteDatabase sqLiteDatabase) {
        //Creating the three tables Courses, Modules and is_in)
        String CREATE_COURSE_TABLE = "CREATE TABLE" + TABLE_NAME1 + "("+colc_1+"VARCHAR(6) PRIMARY KEY,"+colc_2+"TEXT"+")";
        sqLiteDatabase.execSQL(CREATE_COURSE_TABLE);
        String CREATE_MODULE_TABLE = "CREATE TABLE" + TABLE_NAME2 +
                "("+colm_1+"VARCHAR(6) PRIMARY KEY,"+colm_2+"TEXT"+colm_3+"TEXT"+colm_4+"VARCHAR(6)"
                +colm_5+"INTEGER"+colm_6+"VARCHAR(6)"+colm_7 + "TEXT" + colm_8 + "INTEGER" +")";
        sqLiteDatabase.execSQL(CREATE_MODULE_TABLE);
        String CREATE_RELATIONAL_TABLE = "CREATE TABLE" + TABLE_NAME3 + "("+coli_1+"VARCHAR(6) PRIMARY KEY,"+coli_2+"TEXT"+")";
        sqLiteDatabase.execSQL(CREATE_RELATIONAL_TABLE);
    }

    @Override
    public void onUpgrade(android.database.sqlite.SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //Drop older tables, if in any case they exist
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME1);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME2);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME3);

        //Recreate the tables
        onCreate(sqLiteDatabase);
    }

    public long insertCourseData(String courseid, String coursename) {
        android.database.sqlite.SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(colc_1, courseid);
        values.put(colc_2, coursename);
        long result = sqLiteDatabase.insert(TABLE_NAME1, null, values);
        /*if (result == -1) {
            return false;
        } else {
            return true;
        }*/
        return result;
    }

    public Courses getCourseData(String courseid) {
        android.database.sqlite.SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM" + TABLE_NAME1 + "WHERE" + colc_1 + "=" + courseid;

        Log.e(LOG, selectQuery);

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null) {
            c.moveToFirst();
        }
        Courses cr = new Courses();
        cr.setCourseID(c.getString(c.getColumnIndex(colc_1)));
        cr.setC_n(c.getString(c.getColumnIndex(colc_2)));

        return cr;
    }

    public long insertModuleData(String moduleid, String modulename, String venue, String time, int semester, String course, String day, int year) {
        android.database.sqlite.SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(colm_1, moduleid);
        values.put(colm_2, modulename);
        values.put(colm_3, venue);
        values.put(colm_4, time);
        values.put(colm_5, semester);
        values.put(colm_6, course);
        values.put(colm_7, day);
        values.put(colm_8, year);
        long result = sqLiteDatabase.insert(TABLE_NAME1, null, values);
        /*if (result == -1) {
            return false;
        } else {
            return true;
        }*/
        return result;
    }

    public Modules getModuleData(String moduleid) {
        android.database.sqlite.SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM" + TABLE_NAME2 + "WHERE" + colm_1 + "=" + moduleid;

        Log.e(LOG, selectQuery);

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null) {
            c.moveToFirst();
        }
        Modules m = new Modules();
        m.setM_ID(c.getString(c.getColumnIndex(colm_1)));
        m.setM_n(c.getString(c.getColumnIndex(colm_2)));
        m.setM_v(c.getString(c.getColumnIndex(colm_3)));
        m.setM_time(c.getString(c.getColumnIndex(colm_4)));
        m.setM_sem(c.getInt(c.getColumnIndex(colm_5)));
        m.setM_c(c.getString(c.getColumnIndex(colm_6)));
        m.setM_d(c.getString(c.getColumnIndex(colm_7)));
        m.setM_y(c.getInt(c.getColumnIndex(colm_8)));

        return m;
    }

}
