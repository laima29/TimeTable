package com.example.owner.timetableapp;

/**
 * Created by Owner on 20/01/2018.
 */

public class IsIn {
    String c_id;
    String m_id;

    public IsIn(){

    }

    public IsIn(String cid, String mid){
        this.c_id = cid;
        this.m_id = mid;
    }

    public String getCID(){

        return c_id;
    }

    public void setCID(String cid){

        this.c_id = cid;
    }

    public String getMID(){

        return m_id;
    }

    public void setMID(String mid){

        this.m_id = mid;
    }
}
